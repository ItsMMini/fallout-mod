package mini.fallout.util.compat.jei;

import mini.fallout.util.Reference;

public class RecipeCategories 
{
	public static final String COOKING_STATION = Reference.MODID + ".cooking_station";
}
