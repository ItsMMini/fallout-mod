package mini.fallout.util;

public interface IhasModel 
{
	public void registerModels();
}
