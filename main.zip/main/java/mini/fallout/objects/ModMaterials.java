package mini.fallout.objects;

import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.material.MaterialLiquid;

public class ModMaterials 
{
	public static final Material RADIATION = new MaterialLiquid(MapColor.GRAY_STAINED_HARDENED_CLAY);
}
